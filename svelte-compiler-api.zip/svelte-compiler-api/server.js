const express = require('express');
const svelte = require('svelte/compiler');
const bodyParser = require('body-parser');
const cors = require('cors');

const app = express();

app.use(cors());
app.use(bodyParser.json());

// Handle POST requests to /api/compile-post
app.post('/api/post', (req, res) => {
  const { code } = req.body;

  if (!code) {
    return res.status(400).json({ error: 'No code provided' });
  }

  try {
    const { js } = svelte.compile(code);
    res.json({ js: js.code });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Handle GET requests to /api/compile-get
app.get('/api/get', (req, res) => {
  const { code } = req.query;

  if (!code) {
    return res.status(400).json({ error: 'No code parameter provided' });
  }

  try {
    const { js } = svelte.compile(code);
    res.json({ js: js.code });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Export handler for Vercel
module.exports = (req, res) => {
  app(req, res);
};
